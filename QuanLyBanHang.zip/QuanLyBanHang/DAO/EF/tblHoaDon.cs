namespace DAO.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("tblHoaDon")]
    public partial class tblHoaDon
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int IDHoaDon { get; set; }

        public int IDKhachHang { get; set; }

        public int IDNhanVien { get; set; }

        public DateTime ThoiGian { get; set; }

        public int IDHangHoa { get; set; }

        public int SoLuong { get; set; }

        public int DonGia { get; set; }

        public virtual tblHangHoa tblHangHoa { get; set; }

        public virtual tblKhachHang tblKhachHang { get; set; }

        public virtual tblNhanVien tblNhanVien { get; set; }
    }
}
