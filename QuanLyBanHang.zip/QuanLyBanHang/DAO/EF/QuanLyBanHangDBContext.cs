namespace DAO.EF
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class QuanLyBanHangDBContext : DbContext
    {
        public QuanLyBanHangDBContext()
            : base("name=QuanLyBanHangDBContext")
        {
        }

        public virtual DbSet<tblHangHoa> tblHangHoas { get; set; }
        public virtual DbSet<tblHoaDon> tblHoaDons { get; set; }
        public virtual DbSet<tblKhachHang> tblKhachHangs { get; set; }
        public virtual DbSet<tblNhanVien> tblNhanViens { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
        }
    }
}
